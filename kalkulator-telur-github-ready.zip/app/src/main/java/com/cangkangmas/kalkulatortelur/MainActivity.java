package com.cangkangmas.kalkulatortelur;

import android.app.Activity;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {

    private EditText inputJumlahTelur;
    private EditText inputHargaTelur;
    private EditText inputJumlahTray;
    private EditText inputHargaTray;

    private TextView textTotalTelur;
    private TextView textTotalTray;
    private TextView textTotalKeseluruhan;

    private final NumberFormat rupiahFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputJumlahTelur = findViewById(R.id.inputJumlahTelur);
        inputHargaTelur = findViewById(R.id.inputHargaTelur);
        inputJumlahTray = findViewById(R.id.inputJumlahTray);
        inputHargaTray = findViewById(R.id.inputHargaTray);

        textTotalTelur = findViewById(R.id.textTotalTelur);
        textTotalTray = findViewById(R.id.textTotalTray);
        textTotalKeseluruhan = findViewById(R.id.textTotalKeseluruhan);

        Button btnHitung = findViewById(R.id.btnHitung);
        btnHitung.setOnClickListener(view -> hitungTotal());

        setEnterAction(inputJumlahTelur);
        setEnterAction(inputHargaTelur);
        setEnterAction(inputJumlahTray);
        setEnterAction(inputHargaTray);

        // Hitung nilai awal dari contoh angka yang tampil di layar.
        hitungTotal();
    }

    private void setEnterAction(EditText editText) {
        editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        editText.setSelectAllOnFocus(true);
        editText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                hitungTotal();
                return false;
            }
            return false;
        });
    }

    private void hitungTotal() {
        double jumlahKgTelur = parseKg(inputJumlahTelur.getText().toString());
        long hargaTelurPerKg = parseRupiah(inputHargaTelur.getText().toString());
        long jumlahTray = parseRupiah(inputJumlahTray.getText().toString());
        long hargaTrayPerBuah = parseRupiah(inputHargaTray.getText().toString());

        long totalTelur = Math.round(jumlahKgTelur * hargaTelurPerKg);
        long totalTray = jumlahTray * hargaTrayPerBuah;
        long totalKeseluruhan = totalTelur + totalTray;

        textTotalTelur.setText(formatRupiah(totalTelur));
        textTotalTray.setText(formatRupiah(totalTray));
        textTotalKeseluruhan.setText(formatRupiah(totalKeseluruhan));
    }

    private double parseKg(String value) {
        if (value == null || value.trim().isEmpty()) return 0;

        // Untuk kg: boleh pakai koma atau titik sebagai desimal.
        // Contoh: 100,5 atau 100.5 akan dibaca 100.5 kg.
        String clean = value.trim()
                .replace(" ", "")
                .replace(",", ".")
                .replaceAll("[^0-9.]", "");

        if (clean.isEmpty()) return 0;

        try {
            return Double.parseDouble(clean);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private long parseRupiah(String value) {
        if (value == null || value.trim().isEmpty()) return 0;

        // Untuk harga: 23000, 23.000, atau Rp23.000 semua dibaca 23000.
        String clean = value.replaceAll("[^0-9]", "");
        if (clean.isEmpty()) return 0;

        try {
            return Long.parseLong(clean);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String formatRupiah(long value) {
        String formatted = rupiahFormat.format(value);
        // Android biasanya menghasilkan "Rp2.300.000,00".
        // Dibuat lebih ringkas menjadi "Rp 2.300.000".
        formatted = formatted.replace(",00", "");
        formatted = formatted.replace("Rp", "Rp ");
        formatted = formatted.replace("Rp  ", "Rp ");
        return formatted;
    }
}
