# Kalkulator Telur

Aplikasi Android native sederhana untuk menghitung total kebutuhan telur dan tray/peti.

## Fungsi

- Input jumlah telur dalam kg.
- Input harga telur per kg.
- Input jumlah tray/peti dalam buah.
- Input harga tray/peti per buah.
- Tombol HITUNG menampilkan hasil.
- Bagian input bisa diketuk dan diedit.
- Bagian hasil hanya tampilan, tidak bisa diedit.

## Rumus

```text
Total harga telur = jumlah kg telur × harga telur per kg
Total harga tray/peti = jumlah tray/peti × harga tray/peti per buah
Total keseluruhan = total harga telur + total harga tray/peti
```

## Struktur root repository yang benar

Saat di-upload ke GitHub, posisi file harus seperti ini:

```text
.github/workflows/build-apk.yml
app/build.gradle
app/src/main/AndroidManifest.xml
build.gradle
gradle.properties
settings.gradle
README.md
```

Jangan sampai menjadi seperti ini:

```text
kalkulator-telur/.github/workflows/build-apk.yml
kalkulator-telur/app/build.gradle
```

Kalau ada folder `kalkulator-telur` di dalam repository, workflow GitHub Actions tidak akan terbaca.

## Build APK di GitHub

1. Buat repository baru di GitHub.
2. Upload semua isi project ke root repository.
3. Buka tab Actions.
4. Jalankan workflow Build APK.
5. Setelah selesai, download artifact `KalkulatorTelur-debug-apk`.
6. Ekstrak artifact tersebut.
7. File APK ada di dalamnya dengan nama `app-debug.apk`.

## Logo aplikasi

Project ini memakai logo kalkulator yang dipilih, tersimpan di:

```text
app/src/main/res/drawable/logo_kalkulator.png
```
